#include "letters_bag.h"

//A completar
