//
// Created by 
//

#ifndef DICTIONARY_H
#define DICTIONARY_H


#include <string>
#include <iostream>
#include <set>

#include <vector>
using namespace std;

class Dictionary {
private:


  set<string> words;

//A completar






};
#endif //DICTIONARY_H
