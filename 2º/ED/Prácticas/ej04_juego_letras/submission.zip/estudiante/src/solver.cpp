#include <iostream>

#include "solver.h"

using namespace std;

Solver::Solver(const Dictionary &dict, const LettersSet &letters_set) {
    this->d = dict;
    this->ls = letters_set;
}

pair<vector<string>, int> Solver::getSolutions(const vector<char> &available_letters, bool score_game) {
    int score = 0, curr_score;
    vector<string> solutions;
    vector<string>::const_iterator i = (d.getWords(available_letters)).cbegin();

    while(i != (d.getWords(available_letters)).cend()){
        if(score_game) curr_score = ls.getScore(*i);
        else curr_score = (*i).size();

        if(curr_score == score) solutions.push_back(*i);
        else if(curr_score > score){
            solutions.clear();
            solutions.push_back(*i);
            score = curr_score;
        }
        i++;
    }

    pair<vector<string>, int> solution = {solutions, score};
    return solution;
}