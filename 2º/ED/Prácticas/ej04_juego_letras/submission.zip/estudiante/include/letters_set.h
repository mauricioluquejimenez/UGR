#ifndef __LETTER_SET_H__
#define __LETTER_SET_H__

/**
 * @brief TDA LetterInfo
 *
 * Contiene información sobre un determinado carácter del juego de las
 * letras. En concreto, almacena información sobre el número de repeticiones de
 * la letra en la partida y de la puntuación que otorga al utilizarse en una
 * palabra
 */

struct LetterInfo{
    int repetitions, score;
};

/**
 * @brief TDA LettersSet
 *
 * Este TDA representa un conjunto de letras, con la información necesaria para
 * jugar una partida al juego de las letras, es decir, el número de repeticiones
 * que tenemos de la letra y la puntuación que dicha letra otorga cuando se
 * utiliza en una palabra
 */

#include <iostream>
#include <map>

using namespace std;

class LettersSet{
private:
    map<char, LetterInfo> letters;
public:
    LettersSet();
    LettersSet(const LettersSet & other);
    bool insert(const pair<char,LetterInfo> & val);
    bool erase(const char & key);
    bool empty() const;
    void clear();
    unsigned int size();
    int getScore(string word);
    LettersSet & operator = (const LettersSet & cl);
    LetterInfo & operator [] (const char & val);
    friend ostream & operator << (ostream & os, const LettersSet & cl);
    friend istream & operator >> (istream & is, LettersSet & cl);

    class iterator{
    private:
        map<char,LetterInfo>::iterator i;
    public:
        iterator(){}
        iterator(const map<char,LetterInfo>::iterator & other): i(other){}
        iterator(const iterator & other):i(other.i){}
        ~iterator(){}
        iterator & operator = (const map<char,LetterInfo>::iterator & other){i = other; return *this;}
        iterator & operator = (const iterator & other) {i = other.i; return *this;}
        const pair<char,LetterInfo> operator * () const{return *i;}
        iterator & operator ++ () {++i; return *this;}
        iterator & operator -- () {--i; return *this;}
        iterator & operator ++ (int) {i++; return *this;}
        iterator & operator -- (int) {i--; return *this;}
        bool operator != (const iterator & other) {return i != other.i;}
        bool operator == (const iterator & other) {return i == other.i;}
    };

    iterator begin() { iterator i = letters.begin(); return i; }
    iterator end() { iterator i = letters.end(); return i; }

    class const_iterator{
    private:
        map<char,LetterInfo>::const_iterator i;
    public:
        const_iterator(){}
        const_iterator(const map<char,LetterInfo>::const_iterator & other): i(other){}
        const_iterator(const const_iterator & other):i(other.i){}
        ~const_iterator(){}
        const_iterator & operator = (const map<char,LetterInfo>::const_iterator & other){i = other; return *this;}
        const_iterator & operator = (const const_iterator & other) {i = other.i; return *this;}
        const pair<char,LetterInfo> operator * () const{return *i;}
        const_iterator & operator ++ () {++i; return *this;}
        const_iterator & operator -- () {--i; return *this;}
        const_iterator & operator ++ (int) {i++; return *this;}
        const_iterator & operator -- (int) {i--; return *this;}
        bool operator != (const const_iterator & other) {return i != other.i;}
        bool operator == (const const_iterator & other) {return i == other.i;}
    };

    const_iterator cbegin() const { const_iterator i = letters.begin(); return i; }
    const_iterator cend() const { const_iterator i = letters.end(); return i; }


};

ostream & operator << (ostream & os, const LettersSet & cl);
istream & operator >> (istream & is, LettersSet & cl);

#endif
