#ifndef __BAG_H__
#define __BAG_H__

/**
 *  \brief TDA abstracto Bolsa
 *
 *  Este TDA abstracto nos permite trabajar con una colección de elementos que
 *  permite la extracción de elementos de forma aleatoria sin reemplazamiento
 */

#include <iostream>
#include <vector>

using namespace std;

template <class T>

class Bag{
private:
    vector<T> v;
public:
    Bag(){};
    Bag(const Bag<T> & other){ *this = other; }

    void add(const T &element){ v.push_back(element); }

    T get(){
        swap(v.at(rand() % v.size()), v.back());

        T elemento = v.back();
        v.pop_back();

        return elemento;
    }

    void clear(){ v.clear(); }
    unsigned int size() const{ return v.size(); }
    bool empty(){ return v.empty(); }
    const Bag<T> & operator = (const Bag<T> & other){ *this = other; return *this;}
};

#endif
