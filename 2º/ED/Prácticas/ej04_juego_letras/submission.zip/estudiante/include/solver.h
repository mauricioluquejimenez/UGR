#ifndef P04_JUEGO_LETRAS_SOLVER_H
#define P04_JUEGO_LETRAS_SOLVER_H

#include <iostream>
#include <string>
#include <vector>

#include "dictionary.h"
#include "letters_set.h"
#include "letters_bag.h"

using namespace  std;

class Solver {
private:
    Dictionary d;
    LettersSet ls;

public:
    Solver(const Dictionary & dict, const LettersSet & letters_set);
    pair<vector<string>, int> getSolutions(const vector<char> & available_letters, bool score_game);
};

#endif