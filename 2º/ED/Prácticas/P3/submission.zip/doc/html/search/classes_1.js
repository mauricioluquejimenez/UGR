var searchData=
[
  ['maxqueue_15',['MaxQueue',['../classMaxQueue.html',1,'']]],
  ['maxstack_16',['MaxStack',['../classMaxStack.html',1,'']]]
];
