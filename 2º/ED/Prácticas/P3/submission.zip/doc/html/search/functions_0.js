var searchData=
[
  ['empty_21',['empty',['../classMaxQueue.html#adba5dfd3c6b07b142726b5caeb2a3ca5',1,'MaxQueue::empty()'],['../classMaxStack.html#a47c4d2d2f56ad3d059fdd541f10b2f68',1,'MaxStack::empty()']]]
];
