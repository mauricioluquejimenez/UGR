var searchData=
[
  ['front_2',['front',['../classMaxQueue.html#a4ea213bd90756037ee5d236e4042cac2',1,'MaxQueue']]]
];
