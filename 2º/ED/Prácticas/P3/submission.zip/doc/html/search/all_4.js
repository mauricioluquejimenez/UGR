var searchData=
[
  ['size_11',['size',['../classMaxQueue.html#a9ef272e328615fe6cfed4dd496955972',1,'MaxQueue::size()'],['../classMaxStack.html#a2b0467c0d9e085a005e457b5a231d6a5',1,'MaxStack::size()']]]
];
