var searchData=
[
  ['pop_9',['pop',['../classMaxQueue.html#a7e03f10bfb0ccfe9471dc061b7659ef2',1,'MaxQueue::pop()'],['../classMaxStack.html#ab1498f141850cbf2ce83873fa0551747',1,'MaxStack::pop()']]],
  ['push_10',['push',['../classMaxQueue.html#a30bdc6d6949060303ea280b0269cc1cc',1,'MaxQueue::push()'],['../classMaxStack.html#a62e806375fbb972ebb1fcdb633e52c8e',1,'MaxStack::push()']]]
];
