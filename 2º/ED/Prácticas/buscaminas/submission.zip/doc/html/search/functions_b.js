var searchData=
[
  ['tablerografico_95',['TableroGrafico',['../classTableroGrafico.html#a6f09621a58350c79f95a9be8f5e4cf6c',1,'TableroGrafico']]]
];
