var searchData=
[
  ['operator_3c_3c_28',['operator&lt;&lt;',['../classMatriz.html#a01a1966ccbcb00514e8d89afbbbab0f4',1,'Matriz']]],
  ['operator_3d_29',['operator=',['../classMatriz.html#a83d6f9822d6c67463effaf5002c1d5e1',1,'Matriz']]]
];
