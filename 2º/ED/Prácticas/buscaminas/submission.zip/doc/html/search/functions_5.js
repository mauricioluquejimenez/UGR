var searchData=
[
  ['libera_78',['Libera',['../classMatriz.html#a05bd888510be9205d14b3a41dace5049',1,'Matriz']]]
];
