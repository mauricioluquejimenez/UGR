var searchData=
[
  ['btnrightclicked_1',['btnRightClicked',['../classMyButton.html#abe4931362bddfc38aa178ac0047d1c62',1,'MyButton::btnRightClicked()'],['../classTableroGrafico.html#aa44e6afa7f1d08fe7a0b8ccbe109981b',1,'TableroGrafico::btnRightClicked()']]]
];
