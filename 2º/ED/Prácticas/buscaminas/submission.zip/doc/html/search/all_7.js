var searchData=
[
  ['libera_22',['Libera',['../classMatriz.html#a05bd888510be9205d14b3a41dace5049',1,'Matriz']]]
];
