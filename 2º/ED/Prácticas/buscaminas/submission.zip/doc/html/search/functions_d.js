var searchData=
[
  ['writetext_97',['WriteText',['../classConsola.html#a1f5d796e7e1f6902255a81eb33e254f6',1,'Consola']]],
  ['writevector_98',['WriteVector',['../classConsola.html#a6cb88c0da976fd500d071322d4144f34',1,'Consola']]]
];
