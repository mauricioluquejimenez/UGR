var searchData=
[
  ['get_67',['get',['../classMatriz.html#a404b8b942b27e88620a7201b92bbdc52',1,'Matriz']]],
  ['getcasilla_68',['getCasilla',['../classTableroGrafico.html#af72eae75fd534f14add32fe6fd79387c',1,'TableroGrafico']]],
  ['getcasillaelegida_69',['getCasillaElegida',['../classTableroGrafico.html#a665447834a0eb5713bcd2fd99d54220d',1,'TableroGrafico']]],
  ['getconsola_70',['getConsola',['../classVentana.html#a9b7e3020c22457c6d3f8249b2d5d4b16',1,'Ventana']]],
  ['getncols_71',['getNcols',['../classTableroGrafico.html#ad068ed620869203e21937c8135f5e1f5',1,'TableroGrafico']]],
  ['getnrows_72',['getNrows',['../classTableroGrafico.html#aa6e7beeff71005aad9a35c591b9aede9',1,'TableroGrafico']]],
  ['getnumcols_73',['getNumCols',['../classMatriz.html#a899245333589036f7104dda2f578b77a',1,'Matriz']]],
  ['getnumfilas_74',['getNumFilas',['../classMatriz.html#a8093501e16d1ab0567a590d8f4cf45c1',1,'Matriz']]],
  ['getpulsadacasilla_75',['getPulsadaCasilla',['../classTableroGrafico.html#a53c27713edce1520032e7275fab9b7b6',1,'TableroGrafico']]],
  ['gettablerografico_76',['getTableroGrafico',['../classVentana.html#ad05dbd102fb4455676f28e30e515339b',1,'Ventana']]]
];
