var searchData=
[
  ['activeseleccion_0',['activeSeleccion',['../classTableroGrafico.html#a9fc534bf1686506bd3fdec8da2e373a8',1,'TableroGrafico']]]
];
