var searchData=
[
  ['ponerenblanco_83',['PonerEnBlanco',['../classTableroGrafico.html#a7ec8d76b203297646e6c62ad9a91b1d0',1,'TableroGrafico']]],
  ['prompt_84',['prompt',['../classConsola.html#a06d0e6e23bd59d118fc83ac6ecdef77c',1,'Consola']]],
  ['pulsacasilla_85',['pulsaCasilla',['../classTableroGrafico.html#a9bc0611cc00955a1ca922b7fb15235ea',1,'TableroGrafico']]],
  ['putimagen_86',['putImagen',['../classTableroGrafico.html#a33a16207544e84f564cee8d051ae3ba0',1,'TableroGrafico']]],
  ['puttexto_87',['putTexto',['../classTableroGrafico.html#a9a8ecf5a1e3c7a0bc90b2554199b3194',1,'TableroGrafico']]]
];
