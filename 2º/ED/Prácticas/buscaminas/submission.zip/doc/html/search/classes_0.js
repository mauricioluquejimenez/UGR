var searchData=
[
  ['conexion_49',['Conexion',['../classConexion.html',1,'']]],
  ['consola_50',['Consola',['../classConsola.html',1,'']]]
];
