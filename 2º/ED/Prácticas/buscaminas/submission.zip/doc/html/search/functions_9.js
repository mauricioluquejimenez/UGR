var searchData=
[
  ['readchar_88',['ReadChar',['../classConsola.html#a61fe472596f140da2567ee34f1e55633',1,'Consola']]],
  ['readfloat_89',['ReadFloat',['../classConsola.html#ad3a4d4e77ee1c469a699e5824deb259e',1,'Consola']]],
  ['readint_90',['ReadInt',['../classConsola.html#a6cbbf2edb1c2e357dd2ee4c4ea49503b',1,'Consola']]],
  ['readstring_91',['ReadString',['../classConsola.html#a5153e15d03b6a2c6fd5e4896789b68d6',1,'Consola']]]
];
