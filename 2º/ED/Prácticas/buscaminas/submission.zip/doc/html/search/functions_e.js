var searchData=
[
  ['_7ematriz_99',['~Matriz',['../classMatriz.html#aa1f93719088c45ebbc20e0fb6df415d8',1,'Matriz']]],
  ['_7etablerografico_100',['~TableroGrafico',['../classTableroGrafico.html#a7f41eebc706deb4c9cb2056c2a05b67d',1,'TableroGrafico']]]
];
