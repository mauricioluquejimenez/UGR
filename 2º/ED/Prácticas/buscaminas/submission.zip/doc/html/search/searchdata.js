var indexSectionsWithContent =
{
  0: "abcegjklmoprstvw~",
  1: "cjmtv",
  2: "abcgklmoprstvw~",
  3: "o",
  4: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Friends",
  4: "Pages"
};

