var searchData=
[
  ['tablero_42',['Tablero',['../classTablero.html',1,'']]],
  ['tablerografico_43',['TableroGrafico',['../classTableroGrafico.html',1,'TableroGrafico'],['../classTableroGrafico.html#a6f09621a58350c79f95a9be8f5e4cf6c',1,'TableroGrafico::TableroGrafico()']]]
];
