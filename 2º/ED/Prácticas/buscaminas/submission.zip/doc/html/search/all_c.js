var searchData=
[
  ['set_39',['set',['../classMatriz.html#a83742b6ecb9cef45a51582e50310328d',1,'Matriz']]],
  ['setprompt_40',['setPrompt',['../classConsola.html#a99c8860f927b534ca1a3c1a5c1b957d9',1,'Consola']]],
  ['setpulsadacasilla_41',['setPulsadaCasilla',['../classTableroGrafico.html#a48a32198438f7c8028027268a6a7fef6',1,'TableroGrafico']]]
];
