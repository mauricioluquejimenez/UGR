package civitas;

import java.util.ArrayList;

public class Sorpresa {
    private String texto;
    private int valor;
    private MazoSorpresas mazo;
    
    void informe(int actual, ArrayList<Jugador> todos){
        
    }
    void aplicarAJugador(int actual, ArrayList<Jugador> todos){
        
    }
    void aplicarAJugador_pagarCobrar(int actual, ArrayList<Jugador> todos){
        
    }
    void aplicarAJugador_porCasaHotel(int actual, ArrayList<Jugador> todos){
        
    }
    public String toString(){
        return "";
    }
}
