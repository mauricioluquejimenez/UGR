package controladorCivitas;

public enum Respuesta {
    NO,SI;
}
