/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analizador1;

/**
 *
 * @author david
 */

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;
import java.util.HashSet;
import java.util.Set;


public class EjercicioUno {

    public static void main(String[] args) throws CsvValidationException {
        // Variables para el cálculo global
        double puntuacionTotal = 0;
        double votosTotal = 0;
        double totalPersonajes = 0;
        int guionesCount = 0;
        int capitulosCount = 0;

        // Ruta de las carpetas con los archivos CSV
        String allCapitulesFolderPath = "C:\\Users\\david\\Desktop\\CapitulosUnidos";
        String guionesFolderPath = "C:\\Users\\david\\Desktop\\Capitulos";

        // Procesar archivos en la carpeta "AllCapitules"
        File allCapitulesFolder = new File(allCapitulesFolderPath);
        for (File file : allCapitulesFolder.listFiles()) {
            if (file.isFile() && file.getName().endsWith(".csv")) {
                try {
                    
                        CSVParser csvParser = new CSVParserBuilder()
                            .withSeparator(',')
                            .withIgnoreQuotations(false)
                            .build();

                        CSVReader reader = new CSVReaderBuilder(new FileReader(file))
                                .withCSVParser(csvParser)
                                .build();
                        // Lee la primera línea (encabezados) y descártala
                        reader.readNext();

                        // Lee la segunda línea (datos)
                        String data[]= reader.readNext();

                        if (data == null || data.length == 0) {
                            System.out.println("Archivo vacío: " + file.getName());
                            continue; // Salta al siguiente archivo
                        }

                        // Procesa los datos
                        double rating = Double.parseDouble(data[4]); // IMDb rating
                        double votes = Double.parseDouble(data[5]); // IMDb votes
                        puntuacionTotal += rating;
                        
                        votosTotal += votes;
                        capitulosCount++;
                    

                    reader.close();
                } catch (IOException e) {
                }
            }
        }

        // Procesar archivos en la carpeta "Guiones"
        File guionesFolder = new File(guionesFolderPath);
        for (File file : guionesFolder.listFiles()) {
            if (file.isFile() && file.getName().endsWith(".csv")) {
                try {
                    // Configuración de OpenCSV para manejar comas dentro de comillas dobles
                    CSVParser csvParser = new CSVParserBuilder()
                            .withSeparator(',')
                            .withIgnoreQuotations(false)
                            .build();

                    CSVReader guionesReader = new CSVReaderBuilder(new FileReader(file))
                            .withCSVParser(csvParser)
                            .build();

                    // Leer la encabezados y descartarlos
                    guionesReader.readNext();

                    // Inicializar un conjunto para almacenar personajes únicos en este archivo
                    Set<String> charactersInFile = new HashSet<>();

                    String[] data;
                    while ((data = guionesReader.readNext()) != null) {
                        if (data.length > 4) {
                            String character = data[4];
                            if (!charactersInFile.contains(character)) {
                                charactersInFile.add(character);
                              
                            }
                        }
                    }
                    
                    totalPersonajes += charactersInFile.size();

                    guionesCount++;
                    guionesReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        // Cálculo de medias globales
        double mediaPuntuacion = puntuacionTotal / capitulosCount;
        double mediaVotos = votosTotal / capitulosCount;
        double mediaPersonajes = totalPersonajes / guionesCount;

        System.out.println("Valoración media global en la colección AllCapitules: " + mediaPuntuacion);
        System.out.println("Votos promedio en la colección AllCapitules: " + mediaVotos);
        System.out.println("Número de personajes promedio global en la colección Guiones: " + mediaPersonajes);
    }
}

